# Task 1: Print Hello World and brief introduction

print("Hello, World!")
print("My name is Hammad Raza. I'm a student of Robotics and Intelligent Systems at Bahria University. I am currently enrolled in my 5th semester.")
