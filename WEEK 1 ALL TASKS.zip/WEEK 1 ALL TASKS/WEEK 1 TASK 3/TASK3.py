# Task 3: Largest and Smallest among Three Numbers

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
c = float(input("Enter third number: "))

largest = max(a, b, c)
smallest = min(a, b, c)

print(f"The largest number is: {largest}")
print(f"The smallest number is: {smallest}")
